package stepDefinitions;

import io.cucumber.java.en.*;

public class BackgroundDef {

	@Given("first")
	public void first() {
	    // Write code here that turns the phrase above into concrete actions
	    System.out.println("first");
	}
	@When("second")
	public void second() {
	    // Write code here that turns the phrase above into concrete actions
		System.out.println("second");
	}
	@Then("third")
	public void third() {
	    // Write code here that turns the phrase above into concrete actions
		System.out.println("third");
	}
	@Given("background given one")
	public void background_given_one() {
	    // Write code here that turns the phrase above into concrete actions
		System.out.println("given1");
	}
	@When("background when one")
	public void background_when_one() {
	    // Write code here that turns the phrase above into concrete actions
		System.out.println("when1");
	}
	@Then("background then one")
	public void background_then_one() {
	    // Write code here that turns the phrase above into concrete actions
		System.out.println("then1s");
	}
	@Given("background given two")
	public void background_given_two() {
	    // Write code here that turns the phrase above into concrete actions
		System.out.println("given2");
	}
	@When("background when two")
	public void background_when_two() {
	    // Write code here that turns the phrase above into concrete actions
		System.out.println("when2");
	}
	@Then("background then two")
	public void background_then_two() {
	    // Write code here that turns the phrase above into concrete actions
		System.out.println("then2");
	}
}




