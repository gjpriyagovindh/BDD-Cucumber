package stepDefinitions;

import io.cucumber.java.en.*;

public class CommentDef {
	@Given("user is logged in")
	public void user_is_logged_in() {
	    // Write code here that turns the phrase above into concrete actions
	    System.out.println("comment1given");
	}
	@When("userid enters comment")
	public void userid_enters_comment() {
	    // Write code here that turns the phrase above into concrete actions
		System.out.println("commentwhen");
	}
	@Then("comment must be posted in one")
	public void comment_must_be_posted_in_one() {
	    // Write code here that turns the phrase above into concrete actions
	    System.out.println("cmt1then");
	}
	
	@Then("comment must be posted in two")
	public void comment_must_be_posted_in_two() {
	    // Write code here that turns the phrase above into concrete actions
		 System.out.println("cmt2then");
	}

}
