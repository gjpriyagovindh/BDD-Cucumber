package stepDefinitions;

public class PluginDef {

}
