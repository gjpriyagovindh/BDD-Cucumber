package stepDefinitions;

import java.util.List;

import io.cucumber.datatable.DataTable;
import io.cucumber.java.en.*;

public class Definition {
	@Given("User is on the login screen")
	public void user_is_on_the_login_screen() {
	    // Write code here that turns the phrase above into concrete actions
	    System.out.println("**GIVEN**");
	}
	

@When("user provides correct username")
public void user_provides_correct_username(io.cucumber.datatable.DataTable data) {
    // Write code here that turns the phrase above into concrete actions
    // For automatic transformation, change DataTable to one of
    // E, List<E>, List<List<E>>, List<Map<K,V>>, Map<K,V> or
    // Map<K, List<V>>. E,K,V must be a String, Integer, Float,
    // Double, Byte, Short, Long, BigInteger or BigDecimal.
    //
    // For other transformations you can register a DataTableType.
    List<String> table = data.asList();
    System.out.println(table.get(0));
}}


