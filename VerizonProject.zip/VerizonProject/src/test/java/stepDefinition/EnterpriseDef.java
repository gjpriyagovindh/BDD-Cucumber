package stepDefinition;

public class EnterpriseDef {

}
