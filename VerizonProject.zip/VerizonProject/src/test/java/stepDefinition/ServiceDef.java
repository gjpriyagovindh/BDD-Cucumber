package stepDefinition;

public class ServiceDef {

}
